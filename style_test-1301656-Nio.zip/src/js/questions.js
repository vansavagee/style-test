function addAns1Quest1(context) {
    addAction({
        type: "add_ans_quest",
        question: 1,
        answer: 1
    }, context);
}
function addAns2Quest1(context) {
    addAction({
        type: "add_ans_quest",
        question: 1,
        answer: 2
    }, context);
}

function addAns3Quest1(context) {
    addAction({
        type: "add_ans_quest",
        question: 1,
        answer: 3
    }, context);
}

function addAns4Quest1(context) {
    addAction({
        type: "add_ans_quest",
        question: 1,
        answer: 4
    }, context);
}

function addAns5Quest1(context) {
    addAction({
        type: "add_ans_quest",
        question: 1,
        answer: 5
    }, context);
}
function addAns1Quest2(context) {
    addAction({
        type: "add_ans_quest",
        question: 2,
        answer: 1
    }, context);
}

function addAns2Quest2(context) {
    addAction({
        type: "add_ans_quest",
        question: 2,
        answer: 2
    }, context);
}

function addAns3Quest2(context) {
    addAction({
        type: "add_ans_quest",
        question: 2,
        answer: 3
    }, context);
}

function addAns4Quest2(context) {
    addAction({
        type: "add_ans_quest",
        question: 2,
        answer: 4
    }, context);
}

function addAns5Quest2(context) {
    addAction({
        type: "add_ans_quest",
        question: 2,
        answer: 5
    }, context);
}

function addAns1Quest3(context) {
    addAction({
        type: "add_ans_quest",
        question: 3,
        answer: 1
    }, context);
}

function addAns2Quest3(context) {
    addAction({
        type: "add_ans_quest",
        question: 3,
        answer: 2
    }, context);
}

function addAns3Quest3(context) {
    addAction({
        type: "add_ans_quest",
        question: 3,
        answer: 3
    }, context);
}

function addAns4Quest3(context) {
    addAction({
        type: "add_ans_quest",
        question: 3,
        answer: 4
    }, context);
}

function addAns5Quest3(context) {
    addAction({
        type: "add_ans_quest",
        question: 3,
        answer: 5
    }, context);
}
function addAns1Quest4(context) {
    addAction({
        type: "add_ans_quest",
        question: 4,
        answer: 1
    }, context);
}

function addAns2Quest4(context) {
    addAction({
        type: "add_ans_quest",
        question: 4,
        answer: 2
    }, context);
}

function addAns3Quest4(context) {
    addAction({
        type: "add_ans_quest",
        question: 4,
        answer: 3
    }, context);
}

function addAns4Quest4(context) {
    addAction({
        type: "add_ans_quest",
        question: 4,
        answer: 4
    }, context);
}

function addAns5Quest4(context) {
    addAction({
        type: "add_ans_quest",
        question: 4,
        answer: 5
    }, context);
}

function addAns1Quest5(context) {
    addAction({
        type: "add_ans_quest",
        question: 5,
        answer: 1
    }, context);
}

function addAns2Quest5(context) {
    addAction({
        type: "add_ans_quest",
        question: 5,
        answer: 2
    }, context);
}

function addAns3Quest5(context) {
    addAction({
        type: "add_ans_quest",
        question: 5,
        answer: 3
    }, context);
}

function addAns4Quest5(context) {
    addAction({
        type: "add_ans_quest",
        question: 5,
        answer: 4
    }, context);
}

function addAns5Quest5(context) {
    addAction({
        type: "add_ans_quest",
        question: 5,
        answer: 5
    }, context);
}

function addAns1Quest6(context) {
    addAction({
        type: "add_ans_quest",
        question: 6,
        answer: 1
    }, context);
}

function addAns2Quest6(context) {
    addAction({
        type: "add_ans_quest",
        question: 6,
        answer: 2
    }, context);
}

function addAns3Quest6(context) {
    addAction({
        type: "add_ans_quest",
        question: 6,
        answer: 3
    }, context);
}

function addAns4Quest6(context) {
    addAction({
        type: "add_ans_quest",
        question: 6,
        answer: 4
    }, context);
}

function addAns5Quest6(context) {
    addAction({
        type: "add_ans_quest",
        question: 6,
        answer: 5
    }, context);
}

function addAns1Quest7(context) {
    addAction({
        type: "add_ans_quest",
        question: 7,
        answer: 1
    }, context);
}

function addAns2Quest7(context) {
    addAction({
        type: "add_ans_quest",
        question: 7,
        answer: 2
    }, context);
}

function addAns3Quest7(context) {
    addAction({
        type: "add_ans_quest",
        question: 7,
        answer: 3
    }, context);
}

function addAns4Quest7(context) {
    addAction({
        type: "add_ans_quest",
        question: 7,
        answer: 4
    }, context);
}

function addAns5Quest7(context) {
    addAction({
        type: "add_ans_quest",
        question: 7,
        answer: 5
    }, context);
}

function addAns1Quest8(context) {
    addAction({
        type: "add_ans_quest",
        question: 8,
        answer: 1
    }, context);
}

function addAns2Quest8(context) {
    addAction({
        type: "add_ans_quest",
        question: 8,
        answer: 2
    }, context);
}

function addAns3Quest8(context) {
    addAction({
        type: "add_ans_quest",
        question: 8,
        answer: 3
    }, context);
}

function addAns4Quest8(context) {
    addAction({
        type: "add_ans_quest",
        question: 8,
        answer: 4
    }, context);
}

function addAns5Quest8(context) {
    addAction({
        type: "add_ans_quest",
        question: 8,
        answer: 5
    }, context);
}

function addAns1Quest9(context) {
    addAction({
        type: "add_ans_quest",
        question: 9,
        answer: 1
    }, context);
}

function addAns2Quest9(context) {
    addAction({
        type: "add_ans_quest",
        question: 9,
        answer: 2
    }, context);
}

function addAns3Quest9(context) {
    addAction({
        type: "add_ans_quest",
        question: 9,
        answer: 3
    }, context);
}

function addAns4Quest9(context) {
    addAction({
        type: "add_ans_quest",
        question: 9,
        answer: 4
    }, context);
}

function addAns5Quest9(context) {
    addAction({
        type: "add_ans_quest",
        question: 9,
        answer: 5
    }, context);
}

function addAns1Quest10(context) {
    addAction({
        type: "add_ans_quest",
        question: 10,
        answer: 1
    }, context);
}

function addAns2Quest10(context) {
    addAction({
        type: "add_ans_quest",
        question: 10,
        answer: 2
    }, context);
}

function addAns3Quest10(context) {
    addAction({
        type: "add_ans_quest",
        question: 10,
        answer: 3
    }, context);
}

function addAns4Quest10(context) {
    addAction({
        type: "add_ans_quest",
        question: 10,
        answer: 4
    }, context);
}

function addAns5Quest10(context) {
    addAction({
        type: "add_ans_quest",
        question: 10,
        answer: 5
    }, context);
}

function addAns1Quest11(context) {
    addAction({
        type: "add_ans_quest",
        question: 11,
        answer: 1
    }, context);
}

function addAns2Quest11(context) {
    addAction({
        type: "add_ans_quest",
        question: 11,
        answer: 2
    }, context);
}

function addAns3Quest11(context) {
    addAction({
        type: "add_ans_quest",
        question: 11,
        answer: 3
    }, context);
}

function addAns4Quest11(context) {
    addAction({
        type: "add_ans_quest",
        question: 11,
        answer: 4
    }, context);
}

function addAns5Quest11(context) {
    addAction({
        type: "add_ans_quest",
        question: 11,
        answer: 5
    }, context);
}
function GoToResults(context) {
     addAction({
        type: "go_to_results"
    }, context);   
}
function reloadTest(context){
     addAction({
        type: "reload_test"
    }, context);  
}